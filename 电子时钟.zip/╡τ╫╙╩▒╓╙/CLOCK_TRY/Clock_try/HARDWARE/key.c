#include"stm32f10x.h"
#include"key.h"	 

u8 keysta[4]={1,1,1,1};//1��������0��������
u16 KeyDownTime[4]={0,0,0,0};//ע����u16;

extern void KeyAction(int code,u8 sta);//�ڶ��������������̰�
void Key_Init()
{
  GPIO_InitTypeDef   GPIO_InitStructure;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB, ENABLE);
 
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_8;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1|GPIO_Pin_2;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
}

void KeyDriver(void)
{
	static u8 backup[4]={1,1,1,1};
	static u16 TimeThr[4]={2000,2000,2000,2000};  //��������0.8s:1s
	u8 i=0;
	for(i=0;i<4;i++)
	{
		if(keysta[i]!=backup[i])
		{
			if(backup[i]!=0)
			{
				KeyAction(i+1,0);//�ڶ��������̰�
			}
			backup[i]=keysta[i];
		}
		if(KeyDownTime[i]>0)//����
		{
			if(KeyDownTime[i]>TimeThr[i])
			{
				KeyAction(i+1,1);//�ڶ�����������
				TimeThr[i]+=200;
			}
		}
		else//����
		{
			TimeThr[i]=2000;	
		}
	}
}

void KeyScan(void)
{
	u8 i=0;
	static u8 keybuf[4]={0xff,0xff,0xff,0xff};
	keybuf[0]=(keybuf[0]<<1)|KEY1;
   	keybuf[1]=(keybuf[1]<<1)|KEY2;
	keybuf[2]=(keybuf[2]<<1)|KEY3;
	keybuf[3]=(keybuf[3]<<1)|KEY4;
	for(i=0;i<4;i++)
	{
		if(keybuf[i]==0xff)
		{
			keysta[i]=1;
			KeyDownTime[i]=0;
		}
		else if(keybuf[i]==0x00)
		{
			keysta[i]=0;
			KeyDownTime[i]+=4;
		}
		else
		{
			
		}
	}
	
}







