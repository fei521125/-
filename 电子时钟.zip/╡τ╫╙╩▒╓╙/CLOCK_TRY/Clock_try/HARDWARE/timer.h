#ifndef _TIMER_H
#define _TIMER_H

void TIM4_Init(u16 period, u16 prescaler);

#endif





