#ifndef _E2PROM_H
#define _E2PROM_H

void E2Write(u8 addr, u8 dat);
u8 E2Read(u8 addr);

#endif



