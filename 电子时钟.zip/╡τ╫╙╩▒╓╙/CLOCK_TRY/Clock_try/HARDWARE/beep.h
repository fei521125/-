#ifndef BEEP_H
#define BEEP_H


void Beep_Init(void);
#endif