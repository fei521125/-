#ifndef _PWM_H
#define _PWM_H


void PWM_Init(u32 freq, u8 duty,u8 sta);

#endif